/*
 *  glib.h
 *  MultiMarkdown
 *
 *  Created by Daniel Jalkut on 7/26/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

/* Just a dummy file to keep the glib-dependent sources compiling as we would hope */
#include "GLibFacade.h"
