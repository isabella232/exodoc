#ifndef ODF_H
#define ODF_H

#include <stdlib.h>
#include <stdio.h>
#include <glib.h>

void print_odf_header(GString *out);
void print_odf_footer(GString *out);
#endif

