# Run this script to update the various submodules linked to
# from this project

git submodule init
git submodule update
